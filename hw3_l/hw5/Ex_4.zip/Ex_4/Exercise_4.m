% By Julius K. Funken, November 2017

close all;
clear;
clc;

% Transition probability matrix
g1 = 0.975;
g2 = 0.95;
G = [g1 1-g1 ; 1-g2 g2];
J = size(G,1);

% Stationary density (c)
d = ones(1,J)*inv(eye(J) - G + ones(J));
d1 = d(1,1);
d2 = d(1,2);

% Parameters
mu = [0;10];
mu1 = mu(1,1);
mu2 = mu(2,1);
sigma = [1;1];
sigma1 = sigma(1,1);
sigma2 = sigma(2,1);

% Autocorrelation function (a)

EY = d*mu;
EY2 = d*(mu.^2+sigma.^2);
VarY = EY2 - EY^2;

for h=1:200
    Gh(:,:,h) = G^h;
    EYYmh(h) = mu1^2*Gh(1,1,h)*d1 + mu1*mu2*Gh(1,2,h)*d1...
        + mu1*mu2*Gh(2,1,h)*d2 + mu2^2*Gh(2,2,h)*d2;
    Cov(h) = EYYmh(h) - (mu1^2*d1^2 + 2*mu1*mu2*d1*d2 + mu2^2*d2^2);
    Corr(h) = Cov(h)/VarY;
end
Corr = [1 Corr];

% Simulation (b,d)
if rand(1,1)<0.5
    s = 1;
else
    s = 2;
end

T = 10000;
for i=1:T
    if s==1
        if rand(1,1)<g1
            s=1;
        else
            s=2;
        end
    else
        if rand(1,1)<g2
            s=2;
        else
            s=1;
        end
    end
    S(i)=s;
    
    if s==1
        y = mu1+sigma1*randn(1,1);
    else
        y = mu2+sigma2*randn(1,1);
    end
    Y(i) = y;
end
    
% Stationary density (c)
d = ones(1,J)*inv(eye(J) - G + ones(J));

% Empirical autocorrelation (e)
figure
autocorr(Y,200)
corr = autocorr(Y,200);

%Theoretical autocorrelation (f)

figure
hold on
plot(corr,'DisplayName','Empirical')
plot(Corr,'DisplayName','Theoretical')
legend('Location','northwest')
hold off

%Histogram / density (g)
figure
histogram = histogram(Y,50)
hist = histogram.Values;

width = histogram.BinWidth;
lower = histogram.BinLimits(1,1);
upper = histogram.BinLimits(1,2);


x = [lower:width:upper];
pdf1 = normpdf(x,mu1,sigma1);
pdf2 = normpdf(x,mu2,sigma2);
pdf = d1*pdf1 + d2*pdf2;

figure
plot(x,pdf,'DisplayName','Theoretical')
legend('Location','northeast')