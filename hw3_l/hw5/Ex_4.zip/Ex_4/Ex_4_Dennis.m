% By Dennis N. Fischer, Nov 2017

close all;
clear;
clc;

%% a.) Autocorrelation:

% for d=1:200
% theo_acf(d) = ((gamma1*gamma2) - 1)^d
% end 

%% b.) Simulation of the porcess Y(t)

% Parameters:
% mu1 = ;
% mu2 = ;
% sigma1 = ;
% sigma2 = ;
% gamma1 = ;
% gamma2 = ;
% T = ; Length of the simulation 

% Create distribuation 1: 
% pd1 = makedist('Normal','mu',mu1,'sigma',sigma1);
% r1 = random(pd1,1,T);

% Create distribuation 2: 
% pd2 = makedist('Normal','mu',mu2,'sigma',sigma2);
% r2 = random(pd2,1,T);

% Create transition matrix:
% P = [gamma1 (1 - gamma1); (1 - gamma2) gamma2];

% Simulation and "mixing" 
% mc = dtmc(P);
% X = simulate(mc,T);
% for i=1:T
   % if X(i) == 1;
   % Y(1,i)=r1(i);
   % else X(i) == 2;
   % Y(1,i)=r2(i);
   % end
% end 

%% c.) Stationary density 

% h  = (eye (2,2)-P+ones(2,2)); 
% h_inv = inv(h);
% delta = ones(1,3) * h_inv;

%% d.) Simulation 

T = 1D4;

% Distribuation 1
mu1 = 0;
sigma1 = 1;
pd1 = makedist('Normal','mu',mu1,'sigma',sigma1);
r1 = random(pd1,1,T);
figure
hold on
plot(r1)
hold off

% Distribuation 2
mu2 = 10;
sigma2 = 1;
pd2 = makedist('Normal','mu',mu2,'sigma',sigma2);
r2 = random(pd2,1,T);
figure
hold on
plot(r2)
hold off

% Transition matrix
gamma1 = 0.975;
gamma2 = 0.95;
P = [gamma1 (1 - gamma1); (1 - gamma2) gamma2];

% Simulation
mc = dtmc(P);
figure;
hold on
graphplot(mc);
hold off
X = simulate(mc,T);

% "Mixing" 
for i=1:T
    if X(i) == 1;
    Y(1,i)=r1(i);
    else X(i) == 2;
    Y(1,i)=r2(i);
    end
end 

plot(Y)

%% e.) Emperical autocorrelation 

figure
autocorr(Y,200) 
emp_acf = autocorr(Y,200);

%% f.) Theoretical autocorrelation + joint plot

for d=1:200
theo_acf(d) = (2*gamma1 - 1)^d;
end 

figure
hold on
plot(emp_acf,'-.','Color','k');
plot(theo_acf,'--','Color','k');
title('Theoretical and empiriacal autocorrelation ')
legend('Empiriacal' ,'Theoretical','Orientation','horizontal')
hold off 

%% g.) Relative frequency histogram + density of stationary distribuation 

figure
hold on
histo = histogram(Y,100);
hold off
lower = histo.BinLimits(1,1);
upper = histo.BinLimits(1,2);

x= lower:0.1:upper;

pdf1 = pdf(pd1,x);
pdf2 = pdf(pd2,x);

h  = (eye (2,2)-P+ones(2,2)); 
h_inv = inv(h);
delta = ones(1,2) * h_inv;

pdf_mix=pdf1*delta(1,1)+pdf2*delta(1,2);
figure 
hold on 
plot(x,pdf_mix);
hold off

[f,xi] = ksdensity(Y);

figure
hold on 
plot(xi,f,'--','Color','k');
plot(x,pdf_mix,'Color','k');
legend('Kernel' ,'Density of the stationary distribuation','Orientation','horizontal');
hold off
